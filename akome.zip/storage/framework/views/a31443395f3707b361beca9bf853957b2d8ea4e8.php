<!DOCTYPE html>
<html>
<head>
    <title>Home</title>
    <link rel="stylesheet" href="<?php echo e(asset ('css/bootstrap.css')); ?>" type="text/css" />
<style>
img {
  width: 100%;
  height: auto;
}
</style>
</head>
<body>
    <div class="panel-body">
        <div class="col-md-12">                
            <img src="<?php echo e(asset('images/akome.png')); ?>" >
        </div>
    </div>
</body>
</html><?php /**PATH F:\akome\resources\views/home.blade.php ENDPATH**/ ?>