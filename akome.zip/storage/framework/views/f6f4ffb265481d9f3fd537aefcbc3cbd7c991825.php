<?php $__env->startSection('title'); ?>
    Kitchen
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>

<section class="vbox">
    <section class="scrollable padder">
        <ul class="breadcrumb no-border no-radius b-b b-light pull-in">
            <li><a href="index.html"><i class="fa fa-home"></i> Home</a></li>
        </ul>
        <div class="m-b-md">
            <h3 class="m-b-none">Kitchen</h3>
        </div>
        <section class="panel panel-default">
            <header class="panel-heading">
                <i class="fa fa-info-sign text-muted" data-toggle="tooltip" data-placement="bottom" data-title="ajax to load the data."></i>
            </header>

            <div class="panel-body">
                    <div class="col-sm-6">
                        <div class="form-group">
                            <?php $__currentLoopData = $order_infos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order_info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="columns">
                                    <ul class="price">
                                        <li class="header">Table #<?php echo e($order_info->table_id); ?></li>
                                        <?php $__currentLoopData = $order_lists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order_list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($order_list->order_info_id == $order_info->id): ?>
                                                <?php if($order_list->product->category == 'Food'): ?>
                                                   <li> -- <?php echo e($order_list->quantity); ?> &nbsp<?php echo e($order_list->product->product_name); ?></li>
                                                <?php endif; ?>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <li class="grey">
                                            <button onClick="setThumbsFunc(<?=$order_info->table_id?>)" class="btn btn-primary" style="width: 50px"><i class="fa fa-thumbs-up" style="font-size: 23px" ></i></button>
                                            
                                            <button onClick="setCheckFunc(<?=$order_info->table_id?>)" class="btn btn-primary" style="width: 50px"><i class="fa fa-check" style="font-size: 23px"></i></button>
                                        </li>
                                    </ul>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
            </div>

        </section>
    </section>
</section>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
<script>
$(document).ready(function(){
   
  setThumbsFunc=(id)=> {
    console.log(id);
    
    $.ajax({
    url: "<?php echo e(route('order_info.kitchen_thumbs')); ?>",
    method: "POST",
    data: {
        _token: '<?php echo csrf_token(); ?>',
        tableid: id,
     },
    success: function(data){
    }});
        alert('Thumbs: Successfuly sent!');    
   }

  setCheckFunc=(id)=> {
    console.log(id);
    
    $.ajax({
    url: "<?php echo e(route('order_info.kitchen_check')); ?>",
    method: "POST",
    data: {
        _token: '<?php echo csrf_token(); ?>',
        tableid: id,
     },
    success: function(data){
    }});
        alert('Check: Successfuly sent!');    
   }
});

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make(Auth::user()->user_type == 'Admin' ? 'layouts.app' : 'layouts.kitchen_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\akome\resources\views/kitchen/index.blade.php ENDPATH**/ ?>