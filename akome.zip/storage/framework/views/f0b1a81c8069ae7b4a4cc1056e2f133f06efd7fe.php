Click <a href="<?php echo e($link); ?>"> here </a>
<?php /**PATH F:\akome\resources\views/auth/emails/magic.blade.php ENDPATH**/ ?>