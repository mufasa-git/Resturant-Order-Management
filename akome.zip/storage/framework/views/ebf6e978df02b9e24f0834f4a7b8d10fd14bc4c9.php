<?php $__env->startSection('title'); ?>
    Table
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>

<section class="vbox">
    <section class="scrollable padder">
        <ul class="breadcrumb no-border no-radius b-b b-light pull-in">
            <li><a href="index.html"><i class="fa fa-home"></i> Home</a></li>
        </ul>
        <div class="m-b-md">
            <h3 class="m-b-none">Table Map</h3>
        </div>
        <section class="panel panel-default">
            <header class="panel-heading">
                <i class="fa fa-info-sign text-muted" data-toggle="tooltip" data-placement="bottom" data-title="ajax to load the data."></i>
            </header>

            <div class="panel-body" align="center">
                <div class="col-sm-6">
                    <div class="table-map">
                        <?php $__currentLoopData = $tables; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $table): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php  
                                echo '<div class="col-md-6">';
                                ?>
                                <?php if($table->displayed == 0): ?>
                                    <button onClick="setTableFunc(<?=$table->id?>)" class="btn2 btn-primary"><?=$table->id?></button>
                                <?php elseif($table->displayed == 1): ?>
                                    <button onClick="setTableFunc2(<?=$table->id?>)" class="btn2 btn-danger"><?=$table->id?></button>
                                <?php endif; ?>
                                <?php
                                echo '</div>';                                
                            ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                </div>
                    
            </div>

        </section>
    </section>
</section>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
$(document).ready(function(){
   
  setTableFunc=(id)=> {
    var gotoURL= "<?php echo e(route('table.create')); ?>";
    console.log("jason log");
    console.log(id);
    
    $.ajax({
    url: "<?php echo e(route('table.table_status')); ?>",
    method: "POST",
    data: {
        _token: '<?php echo csrf_token(); ?>',
        tableid: id,
        status: "True"
     },
    success: function(data){
        window.location.href = gotoURL;
    }});
    
   }
    setTableFunc2=(id)=> {
        alert('Table'+id+' is full.');       
   }

});

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make(Auth::user()->user_type == 'Admin' ? 'layouts.app' : 'layouts.waiter_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\akome\resources\views/table/index.blade.php ENDPATH**/ ?>