<?php $__env->startSection('title'); ?>
    User
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>

<section class="vbox">
    <section class="scrollable padder">
        <ul class="breadcrumb no-border no-radius b-b b-light pull-in">
            <li><a href="<?php echo e(url('/')); ?>"><i class="fa fa-home"></i> Home</a></li>
            <li class="active">Setting</li>
            <li class="active">User</li>
        </ul>
        <div class="m-b-md">
            <h3 class="m-b-none">User Setting</h3>
        </div>
        <section class="panel panel-default">
            <header class="panel-heading">
                <a href="<?php echo e(route('user.create')); ?>" class="btn btn-primary">Add User</a>
                <button onClick ="$('#table').tableExport({type:'csv',escape:'false'});" class="btn btn-default btn-xs pull-right">CSV</button>
                <button onClick ="$('#table').tableExport({type:'excel',escape:'false'});" class="btn btn-default btn-xs pull-right">Excel</i></button>
                <i class="fa fa-info-sign text-muted" data-toggle="tooltip" data-placement="bottom" data-title="ajax to load the data."></i>
            </header>
            <div class="table-responsive">
                <table class="table table-striped m-b-none" data-ride="datatables" id="table">
                    <thead>
                        <tr>
                            <th width="">Name</th>
                            <th width="">User Type</th>
                            <th width="">Email</th>
                            <th width="150px">Buttons</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($user->name); ?></td>
                                <td><?php echo e($user->user_type); ?></td>
                                <td><?php echo e($user->email); ?></td>
                                <td>
                                    <?php echo e(Form::open(['route' => ['user.destroy', $user->id], 'method' => 'delete', 'style'=>'display:inline-block'])); ?>

                                        <button type="submit" class="btn btn-sm btn-icon btn-danger" onclick="return confirm('Are you sure you want to delete this?')" ><i class="fa fa-trash-o"></i></button>

                                    <?php echo e(Form::close()); ?>

                                    <a href="<?php echo e(route('user.edit',$user->id)); ?>" class="btn btn-sm btn-icon btn-warning"><i class="fa fa-edit"></i></a>

                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </section>
    </section>
 </section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\akome\resources\views/user/index.blade.php ENDPATH**/ ?>