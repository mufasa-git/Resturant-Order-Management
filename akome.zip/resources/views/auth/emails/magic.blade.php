Click <a href="{{ $link }}"> here </a>
